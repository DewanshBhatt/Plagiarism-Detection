# PlagiarismDetection
This is a Plagiarism Detection tool which is implemented in Java. 
